'use client';
import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Volume2, VolumeX } from 'lucide-react';

export default function AudioController() {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Initialize audio element
    audioRef.current = new Audio('https://assets.mixkit.co/music/preview/mixkit-tech-house-vibes-130.mp3'); // Placeholder URL
    audioRef.current.loop = true;
    audioRef.current.volume = 0.4;

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  const toggleAudio = () => {
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(e => console.log("Interaction required first"));
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <motion.button
      onClick={toggleAudio}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 2 }}
      className="fixed bottom-8 right-8 z-50 group"
    >
      <div className="relative flex items-center justify-center w-12 h-12 rounded-full bg-white/80 backdrop-blur-xl border border-white/20 shadow-lg group-hover:scale-110 transition-transform duration-300">

        {/* Visualizer Bars */}
        {isPlaying ? (
           <div className="flex items-end gap-[2px] h-4">
             <motion.div 
               animate={{ height: [4, 12, 6, 16, 4] }} 
               transition={{ repeat: Infinity, duration: 0.5 }} 
               className="w-[2px] bg-black" 
             />
             <motion.div 
               animate={{ height: [8, 4, 16, 8, 8] }} 
               transition={{ repeat: Infinity, duration: 0.7 }} 
               className="w-[2px] bg-black" 
             />
             <motion.div 
               animate={{ height: [12, 8, 4, 12, 12] }} 
               transition={{ repeat: Infinity, duration: 0.6 }} 
               className="w-[2px] bg-black" 
             />
           </div>
        ) : (
           <VolumeX size={16} className="text-gray-400" />
        )}

      </div>

      {/* Tooltip */}
      <span className="absolute right-14 top-1/2 -translate-y-1/2 px-3 py-1 bg-black text-white text-[10px] uppercase tracking-widest rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
        {isPlaying ? 'Mute Ambience' : 'Play Ambience'}
      </span>
    </motion.button>
  );
}