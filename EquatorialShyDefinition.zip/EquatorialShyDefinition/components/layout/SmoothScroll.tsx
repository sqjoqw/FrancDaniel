'use client';
import { ReactNode } from 'react';
import { useSmoothScroll } from '@/hooks/useSmoothScroll'; // Make sure the hook file exists from previous step

export default function SmoothScrollWrapper({ children }: { children: ReactNode }) {
  // Initialize the hook
  useSmoothScroll();

  return (
    <div id="smooth-wrapper" className="w-full min-h-screen overflow-hidden">
      <div id="smooth-content">
        {children}
      </div>
    </div>
  );
}