'use client';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence, useScroll, useMotionValueEvent } from 'framer-motion';
import MagneticButton from '../ui/MagneticButton'; // We will build this next

const LINKS = [
  { name: 'Philosophy', href: '#philosophy' },
  { name: 'Expertise', href: '#expertise' },
  { name: 'Trajectory', href: '#timeline' },
  { name: 'Work', href: '#work' },
  { name: 'Contact', href: '#contact' }
];

export default function Navigation() {
  const { scrollY } = useScroll();
  const [hidden, setHidden] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  // Hide nav on scroll down, show on scroll up
  useMotionValueEvent(scrollY, "change", (latest) => {
    const previous = scrollY.getPrevious() || 0;
    if (latest > previous && latest > 150) {
      setHidden(true);
    } else {
      setHidden(false);
    }
  });

  return (
    <>
      <motion.nav
        variants={{
          visible: { y: 0 },
          hidden: { y: -100 }
        }}
        animate={hidden ? "hidden" : "visible"}
        transition={{ duration: 0.35, ease: "easeInOut" }}
        className="fixed top-0 left-0 right-0 z-[100] px-6 py-6 flex justify-between items-center pointer-events-none"
      >
        {/* Logo Area */}
        <div className="pointer-events-auto">
          <a href="#" className="text-xl font-bold tracking-tighter text-gray-900 mix-blend-difference hover:opacity-50 transition-opacity">
            DF.
          </a>
        </div>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-2 pointer-events-auto bg-white/50 backdrop-blur-xl px-2 py-2 rounded-full border border-white/20 shadow-sm">
          {LINKS.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className="px-5 py-2 text-xs font-bold uppercase tracking-widest text-gray-800 hover:bg-white hover:rounded-full transition-all duration-300"
            >
              {link.name}
            </a>
          ))}
        </div>

        {/* CTA / Mobile Toggle */}
        <div className="pointer-events-auto flex items-center gap-4">
          <div className="hidden md:block">
            <MagneticButton className="px-6 py-2 bg-gray-900 text-white text-xs font-bold uppercase tracking-widest rounded-full">
              Available
            </MagneticButton>
          </div>

          <button 
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden w-10 h-10 bg-white rounded-full flex flex-col items-center justify-center gap-1 shadow-lg pointer-events-auto"
          >
            <span className={`w-4 h-0.5 bg-black transition-transform ${mobileOpen ? 'rotate-45 translate-y-1.5' : ''}`} />
            <span className={`w-4 h-0.5 bg-black transition-opacity ${mobileOpen ? 'opacity-0' : ''}`} />
            <span className={`w-4 h-0.5 bg-black transition-transform ${mobileOpen ? '-rotate-45 -translate-y-1.5' : ''}`} />
          </button>
        </div>
      </motion.nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: '-100%' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: '-100%' }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="fixed inset-0 z-[90] bg-gray-50 flex flex-col justify-center px-6"
          >
            <div className="flex flex-col gap-8">
              {LINKS.map((link, i) => (
                <motion.a
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 + (i * 0.1) }}
                  className="text-5xl font-medium tracking-tight text-gray-900"
                >
                  {link.name}
                </motion.a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}