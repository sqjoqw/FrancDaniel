'use client';
import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';

const MILESTONES = [
  {
    year: '2023 — Present',
    role: 'Media Production Lead',
    org: 'CZ.NIC',
    desc: 'Directing technical and creative quality for the "No Net Drama" campaign. Coordinating editing teams, managing on-set workflows, and ensuring all deliverables meet broadcast standards using DaVinci Resolve.'
  },
  {
    year: '2023',
    role: 'Strategic Campaign Lead',
    org: '53 Schools Project',
    desc: 'Orchestrated a massive PR recruitment campaign. Personally contacted 53 primary school directions, negotiated partnerships, and dispatched student delegations to represent SSPŠ. Resulted in significant applicant interest increase.'
  },
  {
    year: '2022',
    role: 'Hydrogen Engineer',
    org: 'H2 Grand Prix',
    desc: 'Designing, building, and racing 1:10 scale hydrogen-powered RC cars. Focusing on mechanical efficiency, telemetry analysis, and energy management strategies under race conditions.'
  },
  {
    year: '2020',
    role: 'Educational Mentor',
    org: 'DDM Praha 7',
    desc: 'Transitioned from participant to Praktikant leader. Organizing IT camps and teaching Minecraft Education courses. Learned to manage group dynamics and operational logistics.'
  }
];

export default function Timeline() {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start center', 'end center']
  });

  const lineHeight = useTransform(scrollYProgress, [0, 1], ['0%', '100%']);

  return (
    <section ref={containerRef} className="py-32 bg-gray-50 overflow-hidden">
      <div className="container mx-auto max-w-4xl px-6 lg:px-12">
        <div className="text-center mb-24">
          <span className="text-sm font-bold text-blue-600 uppercase tracking-widest">03 — The Path</span>
          <h2 className="text-4xl mt-4 font-medium text-gray-900">Career Trajectory</h2>
        </div>

        <div className="relative">
          {/* Animated Vertical Line */}
          <div className="absolute left-[28px] lg:left-1/2 top-0 bottom-0 w-px bg-gray-200 transform lg:-translate-x-1/2">
            <motion.div 
              style={{ height: lineHeight }}
              className="w-full bg-blue-600 origin-top"
            />
          </div>

          <div className="space-y-24">
            {MILESTONES.map((item, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                className={`flex flex-col ${index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'} items-start lg:items-center relative`}
              >
                {/* Timeline Dot */}
                <div className="absolute left-[20px] lg:left-1/2 w-4 h-4 rounded-full bg-white border-4 border-blue-600 transform lg:-translate-x-1/2 z-10 mt-1 lg:mt-0" />

                {/* Date */}
                <div className={`pl-16 lg:pl-0 lg:w-1/2 ${index % 2 === 0 ? 'lg:pr-16 lg:text-right' : 'lg:pl-16 lg:text-left'} mb-2 lg:mb-0`}>
                  <span className="text-sm font-bold tracking-widest text-gray-400 uppercase">{item.year}</span>
                </div>

                {/* Content */}
                <div className={`pl-16 lg:pl-0 lg:w-1/2 ${index % 2 === 0 ? 'lg:pl-16' : 'lg:pr-16'} lg:text-left`}>
                  <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-300">
                    <h3 className="text-xl font-serif italic text-gray-900 mb-1">{item.role}</h3>
                    <span className="text-xs font-bold text-blue-600 uppercase tracking-wide block mb-4">{item.org}</span>
                    <p className="text-sm text-gray-500 leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}