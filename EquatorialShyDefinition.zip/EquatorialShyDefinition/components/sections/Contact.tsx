'use client';
import { useState } from 'react';
import { motion } from 'framer-motion';

export default function Contact() {
  return (
    <section className="py-32 bg-gray-900 text-white relative overflow-hidden">
      {/* Background Noise for Texture */}
      <div className="absolute inset-0 opacity-20 bg-[url('/noise.png')] mix-blend-overlay pointer-events-none" />

      <div className="container mx-auto px-6 lg:px-12 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24">

          {/* Text Side */}
          <div>
            <span className="text-sm font-bold text-blue-500 uppercase tracking-widest mb-8 block">05 — Initiation</span>
            <h2 className="text-6xl lg:text-8xl font-medium tracking-tighter mb-8">
              Let's <br /> <span className="font-serif italic text-gray-400">Build.</span>
            </h2>
            <p className="text-xl text-gray-400 font-light max-w-md leading-relaxed mb-12">
              Whether it's a media production for a national brand or an engineering challenge. 
              I am ready to execute.
            </p>

            <div className="space-y-4">
              <ContactLink label="Email" value="daniel.franc@email.cz" />
              <ContactLink label="Base" value="Prague, Czechia" />
              <ContactLink label="Status" value="Available for 2026" />
            </div>
          </div>

          {/* Form Side */}
          <div className="bg-white/5 backdrop-blur-md border border-white/10 p-8 lg:p-12 rounded-[32px]">
            <form className="space-y-8">
              <InputGroup label="Name" placeholder="John Doe" />
              <InputGroup label="Email" placeholder="john@example.com" />
              <InputGroup label="Vision" placeholder="Describe your project..." textarea />

              <button className="w-full py-6 bg-white text-black font-bold uppercase tracking-widest rounded-xl hover:bg-blue-600 hover:text-white transition-colors duration-300">
                Transmit Signal
              </button>
            </form>
          </div>

        </div>
      </div>
    </section>
  );
}

function ContactLink({ label, value }: { label: string, value: string }) {
  return (
    <div className="flex items-center gap-4 group cursor-pointer">
      <span className="text-xs uppercase tracking-widest text-gray-500 w-16 group-hover:text-blue-500 transition-colors">{label}</span>
      <span className="text-lg font-medium text-white group-hover:translate-x-2 transition-transform duration-300">{value}</span>
    </div>
  );
}

function InputGroup({ label, placeholder, textarea }: { label: string, placeholder: string, textarea?: boolean }) {
  const [focused, setFocused] = useState(false);

  return (
    <div className="relative">
      <label className={`absolute left-0 transition-all duration-300 ${focused ? '-top-6 text-xs text-blue-500' : 'top-0 text-lg text-gray-500'}`}>
        {label}
      </label>
      {textarea ? (
        <textarea 
          onFocus={() => setFocused(true)}
          onBlur={(e) => setFocused(e.target.value !== '')}
          className="w-full bg-transparent border-b border-gray-700 py-2 text-xl text-white focus:outline-none focus:border-blue-500 transition-colors min-h-[100px]"
        />
      ) : (
        <input 
          type="text" 
          onFocus={() => setFocused(true)}
          onBlur={(e) => setFocused(e.target.value !== '')}
          className="w-full bg-transparent border-b border-gray-700 py-2 text-xl text-white focus:outline-none focus:border-blue-500 transition-colors"
        />
      )}
    </div>
  );
}