'use client';
import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import LiquidGlass from '../ui/LiquidGlass';

export default function Philosophy() {
  const container = useRef(null);
  const { scrollYProgress } = useScroll({
    target: container,
    offset: ['start end', 'end start']
  });

  const y = useTransform(scrollYProgress, [0, 1], [100, -100]);
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0, 1, 1, 0]);

  return (
    <section ref={container} className="relative py-32 px-6 lg:px-12 bg-gray-50 overflow-hidden">
      <div className="container mx-auto max-w-7xl">

        {/* Section Header */}
        <div className="mb-24 lg:mb-32">
          <motion.span 
            className="block text-sm font-bold text-blue-600 uppercase tracking-widest mb-4"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            01 — The Foundation
          </motion.span>
          <motion.h2 
            className="text-4xl lg:text-7xl font-medium tracking-tight text-gray-900 leading-[1.1]"
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            The Intersection of <br />
            <span className="italic font-serif text-gray-400">Logic & Aesthetics.</span>
          </motion.h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-24">

          {/* Left Column: Narrative */}
          <div className="lg:col-span-7 space-y-12">
            <motion.div 
              className="prose prose-lg text-gray-500 font-light"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
            >
              <p className="text-xl leading-relaxed">
                I do not view technology and design as separate entities. Born into a household where 
                <strong> code meets architecture</strong> (my father, a programmer; my mother, an architect), 
                I inherited a dual perspective that defines my professional DNA.
              </p>
              <p>
                From the structural discipline required to build 1:10 scale hydrogen cars to the 
                aesthetic intuition needed for high-end video production, my work exists in the 
                liminal space between "does it work?" and "how does it feel?".
              </p>
              <p>
                I don't just wait for opportunities; I engineer them. This was proven when I orchestrated 
                a recruitment campaign for 53 schools or when I taught myself DaVinci Resolve to meet 
                broadcast standards. I believe in <strong>ToyFight-level precision</strong> applied to every pixel and every frame.
              </p>
            </motion.div>

            {/* Philosophy Points */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { title: "Strategic Autonomy", desc: "I don't need micromanagement. I see the objective, map the route, and execute." },
                { title: "Technical Fluency", desc: "Fluent in both creative tools (Blender, Resolve) and logic (Python, Hydrogen Engineering)." },
                { title: "Leadership by Action", desc: "From captaining football defense at SK Ďáblice to leading production teams." },
                { title: "Relentless Polish", desc: "Good enough is not enough. The details are not the details; they are the design." }
              ].map((item, i) => (
                <LiquidGlass key={i} className="p-8">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{item.title}</h3>
                  <p className="text-sm text-gray-500 leading-relaxed">{item.desc}</p>
                </LiquidGlass>
              ))}
            </div>
          </div>

          {/* Right Column: Visual Metaphor */}
          <motion.div style={{ y }} className="lg:col-span-5 hidden lg:block h-full min-h-[600px] relative">
            <div className="sticky top-32">
               {/* Interactive WebGL placeholder. 
                 Represents the blending of two worlds (Soft shapes vs rigid wireframes).
               */}
               <div className="aspect-[3/4] rounded-3xl overflow-hidden bg-gray-900 relative">
                 <div className="absolute inset-0 opacity-50 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20" />

                 {/* Decorative Elements mimicking architectural blueprints overlaid on code */}
                 <div className="absolute top-10 left-10 right-10 bottom-10 border border-white/10 rounded-xl p-6">
                    <div className="font-mono text-xs text-blue-400 mb-4">
                      // DEFINE_STRUCTURE
                    </div>
                    <div className="grid grid-cols-4 gap-4 opacity-30">
                      {Array.from({ length: 16 }).map((_, i) => (
                        <div key={i} className="aspect-square border border-white/20" />
                      ))}
                    </div>
                    <div className="absolute bottom-6 right-6 text-right">
                       <span className="block text-4xl font-serif text-white italic">Form</span>
                       <span className="block text-4xl font-sans font-bold text-white">Function</span>
                    </div>
                 </div>
               </div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}