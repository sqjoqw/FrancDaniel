'use client';
import { useRef, useEffect } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import gsap from 'gsap';

export default function Hero() {
  const containerRef = useRef<HTMLDivElement>(null);
  const avatarRef = useRef<HTMLDivElement>(null);

  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 500], [0, 200]);
  const y2 = useTransform(scrollY, [0, 500], [0, -150]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Free animation alternative (Staggered fade-in)
      gsap.fromTo(
        '.hero-line',
        { y: 100, opacity: 0 },
        { 
          y: 0, 
          opacity: 1, 
          stagger: 0.15, 
          duration: 1.2, 
          ease: 'power3.out',
          delay: 0.5 
        }
      );

      gsap.fromTo(
        avatarRef.current,
        { scale: 0.9, opacity: 0, filter: 'blur(10px)' },
        { 
          scale: 1, 
          opacity: 1, 
          filter: 'blur(0px)', 
          duration: 1.5, 
          ease: 'power2.out',
          delay: 0.2 
        }
      );
    }, containerRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={containerRef} className="relative h-screen w-full flex items-center justify-center overflow-hidden bg-white">
      <div className="absolute inset-0 bg-gradient-to-b from-white via-white to-gray-50 pointer-events-none" />

      <div className="container relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center px-6 lg:px-12">
        <motion.div style={{ y: y1 }} className="lg:col-span-7 flex flex-col justify-center">
          <div className="overflow-hidden mb-2">
            <p className="hero-line text-sm font-semibold tracking-[0.2em] text-blue-600 uppercase mb-4">
              Visionary Producer & Creative Technologist
            </p>
          </div>

          <div className="relative">
            {/* Split text manually for animation targeting */}
            <h1 className="text-[clamp(3rem,8vw,8rem)] leading-[0.9] font-medium tracking-tight text-gray-900">
              <div className="overflow-hidden"><span className="hero-line block">Architecting</span></div>
              <div className="overflow-hidden"><span className="hero-line block">Digital</span></div>
              <div className="overflow-hidden"><span className="hero-line block text-gray-400 italic font-light">Realities.</span></div>
            </h1>
          </div>

          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            transition={{ delay: 1.5, duration: 1 }}
            className="mt-12 max-w-lg"
          >
            <p className="text-lg text-gray-500 leading-relaxed font-light">
              Bridging the gap between strict engineering logic and cinematic emotion.
              Based in Prague. Currently scaling media production for CZ.NIC and engineering hydrogen futures.
            </p>
          </motion.div>
        </motion.div>

        <motion.div style={{ y: y2 }} className="lg:col-span-5 relative h-[60vh] flex items-center justify-center">
          <div ref={avatarRef} className="relative w-full h-full max-w-[500px]">
             {/* Use your uploaded image here */}
            <div className="absolute inset-0 rounded-[40px] overflow-hidden bg-gray-100 shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-700 ease-[var(--ease-apple)]">
               <div className="w-full h-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
                  <span className="text-9xl font-bold text-gray-300 opacity-20">DF.</span>
               </div>
               {/* Ensure you have an image named daniel-cutout.png in your 'public' folder or root */}
               <img 
                 src="/daniel-cutout.png" 
                 alt="Daniel Franc" 
                 className="absolute inset-0 w-full h-full object-cover"
               />
               <div className="absolute bottom-0 left-0 right-0 h-1/3 bg-gradient-to-t from-white/80 to-transparent backdrop-blur-sm" />
            </div>

            <motion.div 
              className="absolute -bottom-8 -left-8 bg-white/80 backdrop-blur-xl border border-white/40 p-6 rounded-2xl shadow-xl"
              animate={{ y: [0, -10, 0] }}
              transition={{ repeat: Infinity, duration: 5, ease: "easeInOut" }}
            >
               <div className="flex items-center gap-3">
                 <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
                 <span className="text-xs font-bold uppercase tracking-wider text-gray-800">
                   Available for Production
                 </span>
               </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}