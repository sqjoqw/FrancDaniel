'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const SKILLS = [
  {
    id: 'media',
    label: 'Media Production',
    tools: ['DaVinci Resolve Studio', 'Blender 3D', 'FL Studio', 'Adobe Suite'],
    desc: 'Broadcast-quality post-production. From complex color grading in Resolve to architectural visualization in Blender. I manage the entire pipeline from ingest to final render.',
    stats: '4+ Years Experience'
  },
  {
    id: 'engineering',
    label: 'Technical Engineering',
    tools: ['H2 Hydrogen Tech', 'Unreal Engine', 'Frontend Dev', 'Telemetry'],
    desc: 'Hard engineering meets software. Developing energy-efficient hydrogen RC vehicles (1:10 scale) and building interactive digital experiences using Unreal Engine.',
    stats: 'H2 Grand Prix Competitor'
  },
  {
    id: 'leadership',
    label: 'Strategic Leadership',
    tools: ['Project Management', 'Public Relations', 'Team Coordination', 'Conflict Resolution'],
    desc: 'Leading teams under pressure. Whether organizing 53-school campaigns or managing on-set production crews, I ensure the vision is executed without compromise.',
    stats: '53 Schools Managed'
  }
];

export default function ExpertiseDeepDive() {
  const [activeTab, setActiveTab] = useState(SKILLS[0].id);

  return (
    <section className="py-32 bg-white relative z-10">
      <div className="container mx-auto max-w-7xl px-6 lg:px-12">
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-24">

          {/* Navigation / Sidebar */}
          <div className="lg:w-1/3">
            <span className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-8 block">02 — The Arsenal</span>
            <h2 className="text-4xl font-medium mb-12">Technical <br /> Capabilities.</h2>

            <div className="flex flex-col gap-2">
              {SKILLS.map((skill) => (
                <button
                  key={skill.id}
                  onClick={() => setActiveTab(skill.id)}
                  className={`text-left py-6 px-8 rounded-2xl transition-all duration-500 ease-[var(--ease-apple)] border ${
                    activeTab === skill.id 
                      ? 'bg-gray-50 border-gray-200 shadow-sm' 
                      : 'bg-transparent border-transparent hover:bg-gray-50'
                  }`}
                >
                  <span className={`text-lg font-medium block mb-1 ${activeTab === skill.id ? 'text-gray-900' : 'text-gray-400'}`}>
                    {skill.label}
                  </span>
                  <AnimatePresence>
                    {activeTab === skill.id && (
                      <motion.span 
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="text-sm text-blue-600 font-semibold block overflow-hidden"
                      >
                        Explore Capability →
                      </motion.span>
                    )}
                  </AnimatePresence>
                </button>
              ))}
            </div>
          </div>

          {/* Content Area */}
          <div className="lg:w-2/3 relative min-h-[500px]">
            <AnimatePresence mode='wait'>
              {SKILLS.map((skill) => (
                activeTab === skill.id && (
                  <motion.div
                    key={skill.id}
                    initial={{ opacity: 0, x: 50, filter: 'blur(10px)' }}
                    animate={{ opacity: 1, x: 0, filter: 'blur(0px)' }}
                    exit={{ opacity: 0, x: -50, filter: 'blur(10px)' }}
                    transition={{ duration: 0.6, ease: 'circOut' }}
                    className="h-full bg-gray-900 rounded-[32px] p-12 text-white flex flex-col justify-between overflow-hidden relative"
                  >
                    {/* Background Noise/Gradient */}
                    <div className="absolute inset-0 bg-gradient-to-br from-gray-800 to-black opacity-50" />
                    <div className="absolute inset-0 opacity-20 bg-[url('/noise.png')] mix-blend-overlay" />

                    <div className="relative z-10">
                       <div className="flex flex-wrap gap-3 mb-8">
                         {skill.tools.map((tool, i) => (
                           <span key={i} className="px-4 py-2 rounded-full border border-white/20 text-xs uppercase tracking-wider text-white/80 bg-white/5 backdrop-blur-md">
                             {tool}
                           </span>
                         ))}
                       </div>

                       <h3 className="text-3xl font-serif italic text-white/90 mb-6 max-w-xl">
                         {skill.desc}
                       </h3>
                    </div>

                    <div className="relative z-10 border-t border-white/10 pt-8 mt-12 flex items-end justify-between">
                      <div>
                        <span className="block text-xs uppercase tracking-widest text-white/40 mb-2">Key Metric</span>
                        <span className="text-5xl font-bold text-white tracking-tighter">{skill.stats}</span>
                      </div>

                      {/* Visual decoration based on type */}
                      <div className="w-24 h-24 rounded-full border border-white/10 flex items-center justify-center animate-spin-slow">
                        <div className="w-20 h-20 rounded-full border border-dashed border-white/30" />
                      </div>
                    </div>
                  </motion.div>
                )
              ))}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}