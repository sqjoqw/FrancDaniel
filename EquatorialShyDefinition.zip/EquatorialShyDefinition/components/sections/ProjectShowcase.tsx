'use client';
import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import LiquidGlass from '../ui/LiquidGlass';
import { ArrowUpRight } from 'lucide-react';

const PROJECTS = [
  {
    id: 'cznic',
    category: 'Media Production',
    title: 'No Net Drama',
    client: 'CZ.NIC',
    year: '2023',
    desc: 'Lead production for a nationwide awareness campaign. Managed the post-production pipeline in DaVinci Resolve, ensuring broadcast-safe color grading and seamless editing for high-traffic social media deliverables.',
    tags: ['DaVinci Resolve', 'Production Lead', 'Color Grading'],
    image: 'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=1000&auto=format&fit=crop' // Placeholder for video editing suite
  },
  {
    id: 'blender',
    category: '3D Visualization',
    title: 'Architectural Abstractions',
    client: 'Personal / Portfolio',
    year: '2022-2023',
    desc: 'Exploration of liminal spaces using Blender 3D. Focusing on photorealistic lighting, texture mapping, and rigid body physics. Bridging the gap between my parents’ architectural background and my digital canvas.',
    tags: ['Blender 3D', 'Cycles Render', 'Procedural Textures'],
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1000&auto=format&fit=crop' // Placeholder for 3D arch
  },
  {
    id: 'h2',
    category: 'Engineering',
    title: 'H2 Grand Prix Telemetry',
    client: 'School Competition',
    year: '2022',
    desc: 'Development of a 1:10 scale hydrogen-powered RC chassis. My role focused on optimizing energy efficiency through mechanical adjustments and analyzing telemetry data to improve lap times.',
    tags: ['Hydrogen Tech', 'Mechanical Eng', 'Data Analysis'],
    image: 'https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?q=80&w=1000&auto=format&fit=crop' // Placeholder for tech/engineering
  }
];

export default function ProjectShowcase() {
  const container = useRef(null);

  return (
    <section ref={container} className="py-32 bg-white relative z-10 border-t border-gray-100">
      <div className="container mx-auto px-6 lg:px-12">

        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-24">
          <div>
            <span className="text-sm font-bold text-blue-600 uppercase tracking-widest mb-4 block">04 — The Work</span>
            <h2 className="text-5xl lg:text-7xl font-medium tracking-tight text-gray-900">
              Selected <br /> <span className="font-serif italic text-gray-400">Productions.</span>
            </h2>
          </div>
          <div className="mt-8 md:mt-0">
             <span className="text-sm text-gray-400 uppercase tracking-widest">
               Total Projects: {PROJECTS.length}
             </span>
          </div>
        </div>

        {/* Projects Grid */}
        <div className="flex flex-col gap-32">
          {PROJECTS.map((project, i) => (
            <ProjectCard key={project.id} project={project} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ProjectCard({ project, index }: { project: any, index: number }) {
  const cardRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: cardRef,
    offset: ['start end', 'end start']
  });

  const y = useTransform(scrollYProgress, [0, 1], [100, -100]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.95, 1, 0.95]);

  return (
    <motion.div 
      ref={cardRef}
      style={{ scale, opacity: useTransform(scrollYProgress, [0, 0.2], [0.5, 1]) }}
      className="group relative grid grid-cols-1 lg:grid-cols-12 gap-12 items-center"
    >
      {/* Image Area - Parallax */}
      <div className={`lg:col-span-7 relative h-[60vh] overflow-hidden rounded-[32px] ${index % 2 === 1 ? 'lg:order-last' : ''}`}>
        <motion.div style={{ y }} className="absolute inset-0 w-full h-[120%] -top-[10%]">
          <img 
            src={project.image} 
            alt={project.title} 
            className="w-full h-full object-cover filter grayscale group-hover:grayscale-0 transition-all duration-700 ease-[var(--ease-apple)]"
          />
        </motion.div>

        {/* Overlay Gradient */}
        <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors duration-500" />
      </div>

      {/* Content Area */}
      <div className="lg:col-span-5 relative z-10">
        <span className="text-xs font-bold uppercase tracking-widest text-blue-600 mb-2 block">
          {project.client} — {project.year}
        </span>
        <h3 className="text-4xl lg:text-5xl font-medium text-gray-900 mb-6 group-hover:text-blue-600 transition-colors duration-300">
          {project.title}
        </h3>
        <p className="text-lg text-gray-500 leading-relaxed mb-8 font-light">
          {project.desc}
        </p>

        <div className="flex flex-wrap gap-2 mb-10">
          {project.tags.map((tag: string) => (
            <span key={tag} className="px-3 py-1 rounded-full border border-gray-200 text-xs text-gray-500 uppercase tracking-wide">
              {tag}
            </span>
          ))}
        </div>

        <LiquidGlass className="inline-flex">
          <button className="flex items-center gap-2 px-8 py-4 text-sm font-bold uppercase tracking-widest text-gray-900 hover:text-blue-600 transition-colors">
            View Case Study <ArrowUpRight size={18} />
          </button>
        </LiquidGlass>
      </div>
    </motion.div>
  );
}