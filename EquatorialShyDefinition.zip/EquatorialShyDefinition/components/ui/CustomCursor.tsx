'use client';
import { useEffect, useState } from 'react';
import { motion, useSpring, useMotionValue } from 'framer-motion';

export default function CustomCursor() {
  const [hoverState, setHoverState] = useState<'default' | 'button' | 'text' | 'image'>('default');
  const cursorX = useMotionValue(-100);
  const cursorY = useMotionValue(-100);

  const springConfig = { damping: 25, stiffness: 400, mass: 0.5 };
  const springX = useSpring(cursorX, springConfig);
  const springY = useSpring(cursorY, springConfig);

  useEffect(() => {
    const moveCursor = (e: MouseEvent) => {
      cursorX.set(e.clientX);
      cursorY.set(e.clientY);
    };

    const handleHover = (e: MouseEvent) => {
      const target = e.target as HTMLElement;

      if (target.tagName === 'BUTTON' || target.closest('button')) {
        setHoverState('button');
      } else if (target.tagName === 'P' || target.tagName === 'H1' || target.tagName === 'SPAN') {
        setHoverState('text');
      } else if (target.tagName === 'IMG') {
        setHoverState('image');
      } else {
        setHoverState('default');
      }
    };

    window.addEventListener('mousemove', moveCursor);
    window.addEventListener('mouseover', handleHover);

    return () => {
      window.removeEventListener('mousemove', moveCursor);
      window.removeEventListener('mouseover', handleHover);
    };
  }, [cursorX, cursorY]);

  const variants = {
    default: { width: 12, height: 12, backgroundColor: '#1d1d1f', mixBlendMode: 'normal' as any },
    button: { width: 60, height: 60, backgroundColor: 'rgba(255,255,255,0)', border: '1px solid #1d1d1f', mixBlendMode: 'normal' as any },
    text: { width: 4, height: 40, backgroundColor: '#0071e3', borderRadius: 2, mixBlendMode: 'difference' as any },
    image: { width: 80, height: 80, backgroundColor: 'rgba(255,255,255,0.2)', backdropFilter: 'blur(4px)', mixBlendMode: 'overlay' as any },
  };

  return (
    <motion.div
      className="fixed top-0 left-0 pointer-events-none z-[9999] rounded-full flex items-center justify-center"
      style={{
        x: springX,
        y: springY,
        translateX: '-50%',
        translateY: '-50%',
      }}
      animate={hoverState}
      variants={variants}
      transition={{ type: 'spring', stiffness: 500, damping: 28 }}
    >
      {hoverState === 'image' && (
        <span className="text-[10px] uppercase tracking-widest font-bold text-white">View</span>
      )}
    </motion.div>
  );
}