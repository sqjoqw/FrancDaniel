'use client';
import { motion, useScroll } from 'framer-motion';

export default function ScrollProgress() {
  const { scrollYProgress } = useScroll();

  return (
    <div className="fixed top-0 right-0 h-full w-1 z-[50] hidden lg:block">
      <div className="absolute top-0 right-0 h-full w-full bg-gray-200/20" />
      <motion.div
        className="absolute top-0 right-0 w-full bg-blue-600 origin-top"
        style={{ scaleY: scrollYProgress }}
      />
    </div>
  );
}